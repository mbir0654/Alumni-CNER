﻿Public Class Form5
    Private currentUser As Integer
    Private currentDir As Integer
    Public Sub SetCurrentUser(ByVal codu As Integer)
        currentUser = codu
    End Sub
    Dim dir(0 To 100) As Integer
    Private Sub addDir(ByVal parrent As Integer)
        SqlConnection1.Open()

        SqlCommand1.CommandText = "insert into directoare (nume_director, parrent, codu) values ('" + TextBox1.Text + "', " + parrent.ToString + ", " + currentUser.ToString + ")"
        SqlCommand1.ExecuteNonQuery()

        SqlConnection1.Close()
    End Sub
    Private Sub loadDir(ByVal parrent As Integer)
        SqlConnection1.Open()
        Dim s As String
        If parrent = 0 Then
            s = " radacina "
        Else
            SqlCommand1.CommandText = "select nume_director from directoare where codd = " + parrent.ToString
            s = SqlCommand1.ExecuteScalar.ToString
        End If
        Label2.Text = "director parinte: " + s
        Label2.Visible = True

        SqlCommand1.CommandText = "select nume_director, codd from directoare where codu =" + currentUser.ToString + " and parrent = " + parrent.ToString
        currentDir = parrent

        Dim dr As SqlClient.SqlDataReader
        Dim i As Integer = 0
        dr = SqlCommand1.ExecuteReader
        If dr.HasRows Then
            ListBox1.Items.Clear()
            If parrent <> 0 Then
                dir(0) = 0
                ListBox1.Items.Add("..")
                i = 1
            End If
            While dr.Read()
                dir(i) = dr.Item(1)
                ListBox1.Items.Add(dr.Item(0))
                i = i + 1
            End While
        End If
        dr.Close()
        SqlConnection1.Close()
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        If ListBox1.SelectedIndex >= 0 Then
            loadDir(dir(ListBox1.SelectedIndex))
        End If
    End Sub

    Private Sub Form5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        loadDir(0)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text <> "" Then
            addDir(currentDir)
            loadDir(currentDir)
            Form3.reloadDir()
        End If
    End Sub
End Class