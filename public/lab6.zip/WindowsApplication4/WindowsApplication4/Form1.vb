﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim dr As SqlClient.SqlDataReader
        SqlConnection1.Open()


        SqlCommand1.CommandText = "select parola, drepturi, codu from utilizatori where nume_utilizator = '" + username.Text + "'"
        dr = SqlCommand1.ExecuteReader

        If dr.Read Then
            If dr.Item(0) = password.Text Then
                If dr.Item(1).ToString = "admin" Then
                    Form4.SetCurrentUser(dr.Item(2))
                    Form4.Visible = True
                Else
                    Form3.SetCurrentUser(dr.Item(2))
                    Form3.Visible = True
                End If
            Else
                Label4.Visible = True
            End If
            dr.Close()
        Else
            Label4.Visible = True
        End If

        SqlConnection1.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Label5.Visible = True
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Form2.Visible = True
        Me.Visible = False
    End Sub
End Class
