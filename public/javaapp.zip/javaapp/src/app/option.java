package app;

import con.connect;


public class option {
        private connect con=null;
	private boolean o1,o2,o3;
        private Integer id;
        public void save(connect c){
            con = c;
            Integer i1 = o1 == true? 1:0;
            Integer i2 = o2 == true? 1:0;
            Integer i3 = o3 == true? 1:0;
            id = con.insert("insert into optiune (o1,o2,o3) values ("+ i1.toString() + "," + i2.toString() + "," + i3.toString() + ");");
        }
        public option(Integer id, boolean o1, boolean o2, boolean o3){
            this.id=id;
            this.o1 = o1;
            this.o2 = o2;
            this.o3 = o3;
        }
	public option(boolean o1, boolean o2, boolean o3){
		this.o1 = o1;
		this.o2 = o2;
		this.o3 = o3;
	}
	public option(){
		o1 = o2 = o3 = false;
	}
	public option(option o){
		this(o.o1,o.o2,o.o3);
	}
        public Integer getId(){
            return id;
        }
	public boolean equals(option o){
		if (o.o1 == o1 && o.o2 == o2 && o.o3 == o3)
			return true;
		return false;
	}
	public void setOption(int nr,boolean o){
		switch (nr) {
		case 1 : o1=o; break;
		case 2 : o2=o; break;
		case 3 : o3=o; break;
		}
		
	}
        public boolean  getOption(int nr){
		switch (nr) {
		case 1 : return o1;
		case 2 : return o2;
		case 3 : return o3;
		}
                return false;
		
	}

}
