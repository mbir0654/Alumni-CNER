package app;

import con.connect;

public class intrebare {
        private connect con;
        private Integer id;
	private String q;
	private String o1,o2,o3;
	private option r;
	
	public intrebare(connect c){
                con = c;
		q = "";
		o1 = o2 = o3 = " ";
                id = con.insert("insert into intrebare (q,o1,o2,o3,option_id) values ('"+ q + "','" + o1 + "','" + o2 + "','" + o3 + "',0);");
	}
        public intrebare(connect c, Integer id, String q, String o1, String o2, String o3, option r){
            con=c;
            this.id=id;
            this.q=q;
            this.o1=o1;
            this.o2=o2;
            this.o3=o3;
            this.r=r;
        }
        
    
    @Override
        public String toString() {
            return this.q;
        }

	public int getId(){
		return id;
	}
	public void setQuestion(String q){
		this.q = q;
                String s = "update intrebare set q = '"+ this.q +"' where id = "+id.toString()+";";
                con.update(s);
	}
	public String getQuestion(){
		return q;
	}
	public void setTextOption(int nr,String o){
		switch (nr){
		case 1: {
                    o1 = o;
                    con.update("update intrebare set o1 = '"+o1+"' where id = "+id.toString()+";");
                } break;
		case 2: {
                    o2 = o;
                    con.update("update intrebare set o2 = '"+o2+"' where id = "+id.toString()+";");
                } break;
		case 3: {
                    o3 = o;
                    con.update("update intrebare set o3 = '"+o3+"' where id = "+id.toString()+";");
                } break;
		default : return;
		}
	}
	public String getTextOption(int nr){
		switch (nr){
		case 1: {
			return o1; 
		}
		case 2: {
			return o2; 
		}
		case 3: {
			return o3;
		}
		default : return "invalid option";
		}
	}		
	public option getOption(){
		return r;
	}
	public void setOption(option o){
		r = o;
                con.update("update intrebare set option_id = "+r.getId().toString()+" where id = "+id.toString()+";");
	}
        public void delete(){
            con.update("delete from intrebare where id = "+id.toString()+";");
        }
}
