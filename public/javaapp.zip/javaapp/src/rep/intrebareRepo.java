package rep;
import java.util.ArrayList;
import java.util.List;

import app.intrebare;

public class intrebareRepo {
	private List<intrebare> i;
	public intrebareRepo(){
		i = new ArrayList<intrebare>();
	}
	public void add(intrebare i){
		this.i.add(i);
	}
	public boolean find(intrebare i){
		return this.i.contains(i);
	}
        public void delete(int i){
                this.i.remove(i);
        }
	public intrebare getIntrebare(Integer i){
		return this.i.get(i);
	}
	public int length(){
		return i.size();
	}

}
