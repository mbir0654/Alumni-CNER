package rep;

import app.examen;
import java.util.ArrayList;
import java.util.List;

public class examenRepo {
	private List<examen> e;
	public examenRepo(){
		e = new ArrayList<examen>();
	}
	public void add(examen e){
		this.e.add(e);
	}
	public boolean find(examen e){
		return this.e.contains(e);
	}
	public examen getExamen(Integer i){
		return this.e.get(i);
	}
	public int length(){
		return e.size();
	}
}
