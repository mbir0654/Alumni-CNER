package app;

import con.connect;
import java.util.ArrayList;
import java.util.List;

public class examen {
	private Integer id;
	private List<intrebare> intrebari;
	public examen(){

		id = 0;
		intrebari = new ArrayList<intrebare>();
	}
	public examen(Integer id){
		this.id = id;
		intrebari = new ArrayList<intrebare>();
	}
	public void adaugaIntrebare(intrebare i){
		intrebari.add(i);
	}
	public Integer nrIntrebari(){
		return intrebari.size();
	}
	public void stergeIntrebare(intrebare i){
		intrebari.remove(i);
	}
	public intrebare getIntrebare(Integer index){
		return intrebari.get(index);
	}
	public Integer getId(){
		return id;
	}
	public void setId(Integer id){
		this.id = id;
	}
}
