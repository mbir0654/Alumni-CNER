﻿Public Class Form3
    Private currentUser As Integer
    Private currentDir As Integer
    Private currentMsg As Integer
    Dim t As Integer = 0
    Dim dir(0 To 100) As Integer
    Dim msg(0 To 100) As Integer
    Public Sub SetCurrentUser(ByVal codu As Integer)
        currentUser = codu
    End Sub
    Public Sub reloadDir()
        loadDir(currentDir)
    End Sub
    Private Sub deleteDir(ByVal dir As Integer)
        Dim all(0 To 100) As Integer
        Dim i As Integer = 0
        Dim n As Integer = 0
        SqlConnection1.Open()

        SqlCommand1.CommandText = "delete from mesaje where codd = " + dir.ToString
        SqlCommand1.ExecuteNonQuery()

        SqlCommand1.CommandText = "select codd from directoare where parrent = " + dir.ToString
        Dim dr As SqlClient.SqlDataReader = SqlCommand1.ExecuteReader
        While dr.Read
            all(n) = dr.Item(0)
            n = n + 1
        End While

        dr.Close()
        SqlConnection1.Close()

        While i < n
            deleteDir(all(i))
            i = i + 1
        End While

        SqlConnection1.Open()
        SqlCommand1.CommandText = "delete from directoare where codd = " + dir.ToString
        SqlCommand1.ExecuteNonQuery()
        SqlConnection1.Close()
    End Sub
    Private Sub loadDir(ByVal parrent As Integer)
        SqlConnection1.Open()
        SqlCommand1.CommandText = "select nume_director, codd from directoare where codu =" + currentUser.ToString + " and parrent = " + parrent.ToString
        currentDir = parrent

        Dim dr As SqlClient.SqlDataReader
        Dim i As Integer = 0
        dr = SqlCommand1.ExecuteReader
        If dr.HasRows Then
            ListBox1.Items.Clear()
            If parrent <> 0 Then
                dir(0) = 0
                ListBox1.Items.Add("..")
                i = 1
            End If
            While dr.Read()
                dir(i) = dr.Item(1)
                ListBox1.Items.Add(dr.Item(0))
                i = i + 1
            End While
        End If
        dr.Close()
        SqlConnection1.Close()
    End Sub
    Private Sub loadMsg(ByVal codd As Integer)
        SqlConnection1.Open()
        SqlCommand1.CommandText = "select subiect, continut, data, codm, citit from mesaje where destinatar = " + currentUser.ToString + " and codd = " + codd.ToString
        Dim dr As SqlClient.SqlDataReader
        Dim i As Integer = 0
        Dim s As String
        dr = SqlCommand1.ExecuteReader
        ListBox2.Items.Clear()
        While dr.Read
            If dr.Item(4) = True Then
                s = "citit"
            Else
                s = "necitit"
            End If
            msg(i) = dr.Item(3)
            ListBox2.Items.Add(dr.Item(0).ToString + " - " + dr.Item(2).ToString + " - " + s)
            i = i + 1
        End While
        dr.Close()
        SqlConnection1.Close()
    End Sub
    Private Sub viewMsg(ByVal codm As Integer)
        SqlConnection1.Open()

        currentMsg = codm
        SqlCommand1.CommandText = "select continut from mesaje where codm = " + codm.ToString
        Dim dr As SqlClient.SqlDataReader = SqlCommand1.ExecuteReader
        dr.Read()
        TextBox1.Text = dr.Item(0)
        dr.Close()

        SqlCommand1.CommandText = "update mesaje set citit = 1 where codm = " + codm.ToString
        SqlCommand1.ExecuteNonQuery()

        SqlConnection1.Close()
    End Sub
    Private Sub deleteMsg(ByVal codm As Integer)
        SqlConnection1.Open()

        currentMsg = -1
        TextBox1.Text = ""
        SqlCommand1.CommandText = "delete from mesaje where codm = " + codm.ToString
        SqlCommand1.ExecuteNonQuery()

        SqlConnection1.Close()
    End Sub
    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SqlConnection1.Open()
        SqlCommand1.CommandText = "select nume_utilizator from utilizatori where codu = " + currentUser.ToString
        Dim dr As SqlClient.SqlDataReader
        dr = SqlCommand1.ExecuteReader
        dr.Read()
        Label3.Text = "Salut " + dr.Item(0) + "!"
        dr.Close()
        SqlConnection1.Close()

        loadDir(0)
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        If ListBox1.SelectedIndex >= 0 Then
            Dim d As Integer = dir(ListBox1.SelectedIndex)
            TextBox1.Text = ""
            currentMsg = -1
            loadDir(d)
            loadMsg(d)
        End If
    End Sub

    Private Sub ListBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox2.SelectedIndexChanged
        If ListBox2.SelectedIndex >= 0 Then
            viewMsg(msg(ListBox2.SelectedIndex))
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If ListBox2.SelectedIndex >= 0 Then
            deleteMsg(msg(ListBox2.SelectedIndex))
            loadMsg(currentDir)
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Form5.SetCurrentUser(currentUser)
        Form5.Visible = True

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        deleteDir(currentDir)
        loadDir(0)
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Form6.SetCurrentUser(currentUser)
        Form6.Visible = True
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        loadMsg(currentDir)
        'Label4.Visible = True
        'Label4.Text = t.ToString
        't = t + 1
    End Sub
End Class