package app;
import java.rmi.*;
public interface ExecRmiInte extends Remote {
  public String  ping() throws RemoteException;
  public String  upcase(String s) throws RemoteException;
  public Integer add(Integer a, Integer b) throws RemoteException;
}
