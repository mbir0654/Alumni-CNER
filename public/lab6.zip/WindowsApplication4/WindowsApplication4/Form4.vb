﻿Public Class Form4
    Private currentUser As Integer
    Dim users(0 To 100) As Integer
    Public Sub SetCurrentUser(ByVal codu As Integer)
        currentUser = codu
    End Sub
    Private Sub deleteDir(ByVal dir As Integer)
        Dim all(0 To 100) As Integer
        Dim i As Integer = 0
        Dim n As Integer = 0
        SqlConnection1.Open()

        SqlCommand1.CommandText = "delete from mesaje where codd = " + dir.ToString
        SqlCommand1.ExecuteNonQuery()

        SqlCommand1.CommandText = "select codd from directoare where parrent = " + dir.ToString
        Dim dr As SqlClient.SqlDataReader = SqlCommand1.ExecuteReader
        While dr.Read
            all(n) = dr.Item(0)
            n = n + 1
        End While

        dr.Close()
        SqlConnection1.Close()

        While i < n
            deleteDir(all(i))
            i = i + 1
        End While

        SqlConnection1.Open()
        SqlCommand1.CommandText = "delete from directoare where codd = " + dir.ToString
        SqlCommand1.ExecuteNonQuery()
        SqlConnection1.Close()
    End Sub
    Private Sub deleteUser(ByVal codu As Integer)
        Dim dir(0 To 100) As Integer
        SqlConnection1.Open()

        SqlCommand1.CommandText = "delete from mesaje where destinatar = " + codu.ToString
        SqlCommand1.ExecuteNonQuery()

        SqlCommand1.CommandText = "select codd from directoare where codu = " + codu.ToString
        Dim dr As SqlClient.SqlDataReader = SqlCommand1.ExecuteReader
        Dim i As Integer = 0
        Dim n As Integer = 0
        While dr.Read
            dir(n) = dr.Item(0)
            n = n + 1
        End While
        dr.Close()
        SqlConnection1.Close()

        For i = 0 To n - 1
            deleteDir(dir(i))
        Next

        SqlConnection1.Open()
        SqlCommand1.CommandText = "delete from utilizatori where codu=" + codu.ToString
        SqlCommand1.ExecuteNonQuery()
        SqlConnection1.Close()
    End Sub
    Private Sub loadUsers()
        SqlConnection1.Open()

        SqlCommand1.CommandText = "select codu, nume_utilizator from utilizatori where drepturi = 'user'"
        Dim dr As SqlClient.SqlDataReader = SqlCommand1.ExecuteReader
        Dim i As Integer = 0
        ListBox1.Items.Clear()
        While dr.Read
            users(i) = dr.Item(0)
            ListBox1.Items.Add(dr.Item(1))
        End While

        dr.Close()
        SqlConnection1.Close()
    End Sub
    Private Sub Form4_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        loadUsers()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Form3.SetCurrentUser(currentUser)
        Form3.Visible = True
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If ListBox1.SelectedIndex >= 0 Then
            Form3.SetCurrentUser(users(ListBox1.SelectedIndex))
            Form3.Visible = True
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If ListBox1.SelectedIndex >= 0 Then
            deleteUser(users(ListBox1.SelectedIndex))
            loadUsers()
        End If
    End Sub
End Class