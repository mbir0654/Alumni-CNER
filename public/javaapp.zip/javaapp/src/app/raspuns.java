package app;

public class raspuns {
	private option o;
	public raspuns(boolean r1, boolean r2, boolean r3){
		o=new option(r1,r2,r3);
	}
	
	public boolean checkAnswer(intrebare i){
		return o.equals(i.getOption());
	}
}
