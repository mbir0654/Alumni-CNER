﻿Public Class Form2
    Private Function verificare_user(ByVal user As String) As Boolean
        SqlCommand1.CommandText = "select * from utilizatori where nume_utilizator = '" + user + "'"
        Dim dr As SqlClient.SqlDataReader = SqlCommand1.ExecuteReader
        If dr.Read Then
            dr.Close()
            Return False
        Else
            dr.Close()
            Return True
        End If
    End Function

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If password.Text <> password_c.Text Then
            Label4.Text = "Parola si Confirmarea parolei nu coincid"
            Label4.Visible = True
        ElseIf username.Text = "" Then
            Label4.Text = "Nume utilizator nu poate fi gol"
            Label4.Visible = True
        Else
            Dim dr As SqlClient.SqlDataReader
            Dim role As String = "user"
            SqlConnection1.Open()

            SqlCommand1.CommandText = "select count(*) from utilizatori"
            dr = SqlCommand1.ExecuteReader
            dr.Read()
            If dr.Item(0) = 0 Then
                role = "admin"
            End If
            dr.Close()
            If verificare_user(username.Text) Then
                SqlCommand1.CommandText = "insert into utilizatori (nume_utilizator, parola, drepturi) values ('" + username.Text + "', '" + password.Text + "', '" + role + "')"
                Dim r As Integer = SqlCommand1.ExecuteNonQuery
                If r > 0 Then
                    Me.Visible = False
                    Form1.Visible = True
                    SqlCommand1.CommandText = "select codu from utilizatori where nume_utilizator = '" + username.Text + "'"
                    dr = SqlCommand1.ExecuteReader()
                    dr.Read()
                    SqlCommand1.CommandText = "insert into directoare (codu, nume_director, parrent) values (" + dr.Item(0).ToString + ", 'index' , 0)"
                    dr.Close()
                    SqlCommand1.ExecuteNonQuery()
                Else
                    Label4.Text = "Nu s-a putut salva utilizatorul !"
                End If
            Else
                Label4.Text = "Utilizator existent!"
            End If
            SqlConnection1.Close()
        End If
    End Sub
End Class