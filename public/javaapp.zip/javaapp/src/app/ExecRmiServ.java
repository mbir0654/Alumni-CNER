package app;
import java.io.*;
import java.rmi.registry.*;
import java.rmi.server.*;
public class ExecRmiServ {
  public ExecRmiServ(String tip, String host, int port, String nume) throws Exception {
    j1Bib.init(tip, "", port);
    ExecRmiImpl execImpl = new ExecRmiImpl();
    ExecRmiInte stub = (ExecRmiInte) UnicastRemoteObject.exportObject(execImpl, 0);
    Registry registry = LocateRegistry.getRegistry();
    registry.bind(nume, stub);
    System.out.println("Java " + tip + " waiting at: " + host + ":" + port);
  }
/*  public static void main(String [] args) throws Exception {
    if (args.length > 3) 
      new ExecRmiServ(args[0], args[1], Integer.parseInt(args[2]), args[3]); 
    else 
      new ExecRmiServ("RMI", "localhost", 1099, "OBIECT_EXEC");
  }*/
}
