package app;

public class student{

	private	Integer nrmat;
	private String nume;
	private Integer ann;
	private String user;
	private Integer grupa;
	public student() {
		nrmat = 0;
		nume = "";
		ann = 0;
		user = "";
		grupa = 0;
	}
	public boolean valid(){
		if (nrmat == 0 || nume == "" || ann == 0 || user == "" || grupa == 0)
			return false;
		return true;
	}
	public void setNrmat(Integer nr) {
		nrmat = nr;
	}
	public void setNume(String n){
		nume = n;
	}
	public void setAnn(Integer an){
		ann = an;
	}
	public void setUser(String u){
		user = u;
	}
	public void setGrupa(Integer g){
		grupa = g;
	}
	public Integer getNrmat(){
		return nrmat;
	}
	public String getNume(){
		return nume;
	}
	public Integer getAnn(){
		return ann;
	}
	public String getUser(){
		return user;
	}
	public Integer getGrupa(){
		return grupa;
	}
}
