package app;

import java.rmi.registry.*;
public class ExecRmiClie {
  public ExecRmiClie(String tip, String host, int port, String nume) throws Exception {
    Registry registry = LocateRegistry.getRegistry(host);
    ExecRmiInte proxy = (ExecRmiInte) registry.lookup(nume);
    System.out.println("Client Java " + tip + ": " + host + ":" + port);
    String resp1 = proxy.ping();
    System.out.println("ping: \t"+resp1);
    resp1 = proxy.upcase("negru");
    System.out.println("upcase: \tnegru = "+resp1);
    Integer resp2 = proxy.add(66, 75);
    System.out.println("add: \t66 + 75 = "+resp2);
    resp1 = proxy.ping();
    System.out.println("ping: \t"+resp1);
  }
/*  public static void main(String [] args) throws Exception {
    if (args.length > 0) 
      new ExecRmiClie(args[0], args[1], Integer.parseInt(args[2]), args[3]);
    else 
      new ExecRmiClie("RMI", "localhost", 1099, "OBIECT_EXEC");
  }*/
}
