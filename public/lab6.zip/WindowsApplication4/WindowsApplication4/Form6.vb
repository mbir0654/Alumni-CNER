﻿Public Class Form6
    Private currentUser As Integer
    Public Sub SetCurrentUser(ByVal codu As Integer)
        currentUser = codu
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        SqlConnection1.Open()

        SqlCommand1.CommandText = "select codu from utilizatori where nume_utilizator = '" + TextBox1.Text + "'"
        Dim destinatar As Integer = SqlCommand1.ExecuteScalar()
        If destinatar = 0 Then
            SqlCommand1.CommandText = "select codd from directoare where nume_director='index' and codu=" + currentUser.ToString
            Dim codd As Integer = SqlCommand1.ExecuteScalar
            SqlCommand1.CommandText = "select codu from utilizatori where drepturi='admin'"
            Dim expeditor As Integer = SqlCommand1.ExecuteScalar
            SqlCommand1.CommandText = "insert into mesaje (expeditor, destinatar, subiect, continut, codd, citit, data) values (" + expeditor.ToString + ", " + currentUser.ToString + ", 'Mesajul nu a fost livrat', 'Nu exista utilizatorul " + TextBox1.Text + ".  mesajul nu s-a putut trimite!', " + codd.ToString + ",0 ,'" + Date.Now.ToString + "')"
            SqlCommand1.ExecuteNonQuery()
        Else
            SqlCommand1.CommandText = "select codd from directoare where nume_director='index' and codu=" + destinatar.ToString
            Dim codd As Integer = SqlCommand1.ExecuteScalar
            SqlCommand1.CommandText = "insert into mesaje (expeditor, destinatar, subiect, continut, codd, citit, data) values (" + currentUser.ToString + "," + destinatar.ToString + ", '" + TextBox2.Text + "', ' " + TextBox3.Text + "', " + codd.ToString + ",0 , '" + Date.Now.ToString + "')"
            SqlCommand1.ExecuteNonQuery()
        End If

        Me.Visible = False
        SqlConnection1.Close()
    End Sub
End Class