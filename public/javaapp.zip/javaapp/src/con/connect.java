/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package con;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author myh
 */
public class connect {
                private Connection con = null;
                public connect(){

                    try {
                          Class.forName("com.mysql.jdbc.Driver").newInstance();
                          con = DriverManager.getConnection("jdbc:mysql:///map","root", "salut");
		      if(!con.isClosed()){
                        System.out.println("Successfully connected to MySQL server using TCP/IP...");
		      }

		    } catch(Exception e) {
		      System.err.println("Exception: " + e.getMessage());
		    } 
                }
                public void update(String sql){
                    try {
                        Statement s = con.createStatement();
                        s.executeUpdate(sql);
                    } catch (SQLException ex) {
                        System.out.println(ex.getMessage());
                    }

                }
                public int insert(String sql){
                    try {
                        Statement s = con.createStatement();
                        s.executeUpdate(sql);
                        ResultSet res = s.executeQuery("select last_insert_id()");
                        res.next();
                        return res.getInt(1);
                    } catch (SQLException ex) {
                      Logger.getLogger(connect.class.getName()).log(Level.SEVERE, null, ex);
                      System.out.println("problems during insert");
                      }
                    return 0;
                }
                public Connection getCon(){
                    return con;
                }
}
