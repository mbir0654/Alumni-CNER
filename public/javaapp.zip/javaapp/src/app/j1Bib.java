package app;

import java.net.*;
import java.util.*;
public class j1Bib {
  private static String tip = null;
  private static String pathServ = null; 
  private static int port = 0;
  public static String ping() {
    try {
      InetAddress host = InetAddress.getLocalHost();
      return "Java " + tip + " " + pathServ + ": " + host.getHostName() +
        " (" + host.getHostAddress() + ": " + port + "), " + new Date();
    } catch (Exception e) {
      return "ERROR";
    }
  }
  public static String upcase(String s) {
    return s.toUpperCase();
  }
  public static Integer add(Integer a, Integer b) {
    return new Integer(a * b);
  }
  public static void init(String tip, String pathServ, int port) {
    j1Bib.tip = tip;
    j1Bib.pathServ = pathServ;
    j1Bib.port = port;
  }
}
