package app;

import java.rmi.*;
public class ExecRmiImpl implements ExecRmiInte {
  public ExecRmiImpl() throws RemoteException {}
  public String ping() {
    return j1Bib.ping();
  }
  public String upcase(String s) {
    return j1Bib.upcase(s);
  }
  public Integer add(Integer a, Integer b) {
    return j1Bib.add(a, b);
  }
}
