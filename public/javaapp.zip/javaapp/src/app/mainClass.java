package app;
import com.mysql.jdbc.Statement;
import con.connect;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import rep.intrebareRepo;
import java.util.Scanner;
import views.window1;
import java.io.*;
import java.rmi.registry.*;
import java.rmi.server.*;



public class mainClass{

    public mainClass(String tip, String host, int port, String nume) throws Exception {
    j1Bib.init(tip, "", port);
    ExecRmiImpl execImpl = new ExecRmiImpl();
    ExecRmiInte stub = (ExecRmiInte) UnicastRemoteObject.exportObject(execImpl, 0);
    Registry registry = LocateRegistry.getRegistry();
    registry.bind(nume, stub);
    System.out.println("Java " + tip + " waiting at: " + host + ":" + port);
    }
	/**
	 * @param args
	 */
        private static void loadFromDb(connect c,intrebareRepo intrebari){
        try {
            java.sql.Statement s = c.getCon().createStatement();
            ResultSet res = s.executeQuery("select id,q,o1,o2,o3,option_id from intrebare;");
            while(res.next()){
                java.sql.Statement st = c.getCon().createStatement();
                if (res.getInt("option_id") != 0){
                    ResultSet r = st.executeQuery("select id,o1,o2,o3 from optiune where id = "+res.getString("option_id")+";");
                    option o;
                    if (r.next()){
                        o = new option(r.getInt("id"),r.getBoolean("o1"),r.getBoolean("o2"),r.getBoolean("o3"));
                    }
                    else {
                        o = new option();
                    }
                    intrebare q = new intrebare(c,res.getInt("id"),res.getString("q"),res.getString("o1"),res.getString("o2"),res.getString("o3"),o);
                    intrebari.add(q);
                }
            }
        } catch (SQLException ex) {
            //Logger.getLogger(mainClass.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(ex.getMessage());
        }

        }
	public static void main(String[] args) throws Exception {
            	
              //  intrebareRepo Q = new intrebareRepo();
                
                new mainClass("RMI", "localhost", 1099, "OBIECT_EXEC");
                connect c=new connect();
//                window x = new window();
		examen examen = new examen();
		intrebareRepo intrebari = new intrebareRepo();
                
                loadFromDb(c,intrebari);

                new window1(intrebari,c).setVisible(true);

	    //new mainClass();
		for (int i=1;i<=2;i++){
			intrebare q = new intrebare(c);
			System.out.println("Intrebare noua :");
			
			System.out.println("Text intrebare :");
			Scanner ob = new Scanner(System.in);
			String str = ob.nextLine();
			q.setQuestion(str);
			option opt = new option();
			
			for (int k=1;k<=3;k++){
				boolean option;
				System.out.println("Raspuns :");
				str = ob.nextLine();
				q.setTextOption(k, str);
				
				System.out.println("T/F :");
				str = ob.nextLine();
				if (str.equalsIgnoreCase("T"))
					option = true;
				else
					option = false;
				opt.setOption(k, option);
			}
                        opt.save(c);
			q.setOption(opt);
			intrebari.add(q);		
			examen.adaugaIntrebare(q);
		}
		
		/*for (int i=1;i<=2;i++){
			
		}*/
/*		System.out.println(intrebari.length());
		for (int i=0;i<=1;i++) {
			intrebare q = intrebari.getIntrebare(i);
			System.out.println(q.getQuestion());
			option opt = new option();
			for (int k=1;k<=3;k++){
				System.out.println(q.getTextOption(k));
				Scanner ob = new Scanner(System.in);
				boolean option;
				String str = ob.nextLine();
				if (str == "T")
					option = true;
				else
					option = false;
				opt.setOption(k, option);
			}
			if (opt.equals(q.getOption()))
				System.out.println("Corect");
			else
				System.out.println("Gresit");
		}*/
	}

}
